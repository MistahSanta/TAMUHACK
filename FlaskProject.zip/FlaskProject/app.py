# import Algorithm
from flask import Flask, render_template

app = Flask(__name__)

exampleTeamArray = [
    [10, "Floor A", .8],
    [30, "Floor B", .7],
    [20, "Floor C", .9],
    [50, "Floor D", 1]
]

exampleFloorOccupied = [
    .25, .10, 1, .93
]

@app.route('/')
def main():  # put application's code here
    return render_template('teams.html', teamSize = 4, floorSize = 4, teamOverview = exampleTeamArray, floorOccupied = exampleFloorOccupied)

@app.route("/Setting")
def setting2():
    print('setting page is loaded')
    return render_template('setting.html', sites = "Setting")

@app.route('/Preferences')
def setting():
    print('preference page is loaded')
    return render_template('preference.html', sites = "Preferences")


# @app.get("/run_sample")
# def sample():
#     return Algorithm.mainAlgorithm()


if __name__ == '__main__':
    app.run()
